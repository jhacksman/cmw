# Breaking-RSA-using-Shor-s-algorithm

+ File breaking_RSA.ipynb has a step-by-step demonstration of key generation, encryption, shor's attack and decyrption for RSA encryption algorithm.
+ File Shor.ipynb demonstrates factorization of 7 bit integer (119=17*7) on a 32 bit quantum processor provided by IBM
+ shor_119.png is the circuit and histogram.png are mesarement results for this circuit
